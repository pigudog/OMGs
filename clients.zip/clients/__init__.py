# clients/__init__.py
from .wrapper import OpenAIWrapper
__all__ = ["OpenAIWrapper"]
